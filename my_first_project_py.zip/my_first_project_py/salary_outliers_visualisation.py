"""
salary_outliers_visualisation.py

Reads department_stats.csv (produced by my_first_project.py) and plots
average salary by department as a bar chart, saved to
outputs/salary_outliers.png.

Run with:
    python salary_outliers_visualisation.py
"""

import os
import pandas as pd
import matplotlib.pyplot as plt

OUTPUT_DIR = "outputs"


def main():
    stats_path = os.path.join(OUTPUT_DIR, "department_stats.csv")
    if not os.path.exists(stats_path):
        raise FileNotFoundError(
            f"{stats_path} not found. Run my_first_project.py first."
        )

    df = pd.read_csv(stats_path).sort_values("avg_salary", ascending=False)

    fig, ax = plt.subplots(figsize=(8, 5))
    bars = ax.bar(df["dept_name"], df["avg_salary"], color="#4C72B0")

    for bar, value in zip(bars, df["avg_salary"]):
        ax.text(
            bar.get_x() + bar.get_width() / 2,
            bar.get_height() + 500,
            f"{value:,.0f}",
            ha="center",
            va="bottom",
            fontsize=9,
        )

    ax.set_title("Average Salary by Department")
    ax.set_xlabel("Department")
    ax.set_ylabel("Average Salary")
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)

    fig.tight_layout()
    out_path = os.path.join(OUTPUT_DIR, "salary_outliers.png")
    fig.savefig(out_path, dpi=150)
    print(f"Saved chart to {out_path}")


if __name__ == "__main__":
    main()
