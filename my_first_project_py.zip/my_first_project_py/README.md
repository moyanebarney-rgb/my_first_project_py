# my_first_project_py — SQL Portfolio

A complete Python and SQL project demonstrating data analysis skills: creating a database, writing 14 progressive SQL queries, exporting results, and visualising outliers.

---

## 📌 Purpose

This project simulates an employee/department database to demonstrate real-world data analysis skills. It is designed as a portfolio piece for **fiscal analysis and infrastructure economics**.

---

## 📊 The Queries (14 Progressive Steps)

| # | Type | What It Does |
|---|------|---------------|
| 1 | `WHERE` | Filters employees by department |
| 2 | `JOIN` | Combines employee and department data |
| 3 | `WHERE >` | Finds employees earning above a threshold |
| 4 | `GROUP BY` + `SUM` | Total salary per department |
| 5 | `AVG`, `COUNT`, `ORDER BY` | Department statistics |
| 6 | `HAVING` | Departments with avg salary > 70,000 |
| 7 | `ORDER BY DESC` | Departments ranked by total salary |
| 8 | Subquery | Employees above departmental average |
| 9 | CTE | Dept averages vs overall average |
| 10 | `ROW_NUMBER()` | Rank employees within department |
| 11 | `LEAD()` / `LAG()` | Compare to previous/next salary |
| 12 | `RANK()` / `DENSE_RANK()` | Compare ranking methods |
| 13 | `CASE WHEN` | High/low earner percentages |
| 14 | Outlier Detection | Employees above 120% of dept average |

---

## 📁 Files Generated

All 14 queries export to CSV files in the `outputs/` folder.

| File | Description |
|---|---|
| `engineering_team.csv` | Employees in Engineering |
| `employees_with_budgets.csv` | Employees with department budgets |
| `high_earners.csv` | Employees earning > 70,000 |
| `department_salary_totals.csv` | Total salary per department |
| `department_stats.csv` | Department stats |
| `high_avg_departments.csv` | Departments with avg salary > 70,000 |
| `ranked_departments.csv` | Departments ranked by total salary |
| `above_dept_avg.csv` | Employees above departmental average |
| `dept_vs_overall_avg.csv` | Dept averages vs overall average |
| `ranked_employees.csv` | Employees ranked within department |
| `salary_comparison.csv` | LEAD/LAG salary comparison |
| `rank_comparison.csv` | RANK vs DENSE_RANK |
| `conditional_aggregation.csv` | High/low earner percentages |
| `salary_outliers.csv` | Salary outliers |

---

## 📊 Salary Distribution

| Department | Min | Max | Avg | Range |
|---|---|---|---|---|
| Finance | 72,000 | 95,000 | 85,000 | 23,000 |
| Engineering | 71,000 | 92,000 | 81,500 | 21,000 |
| Marketing | 62,000 | 75,000 | 68,300 | 13,000 |
| Operations | 58,000 | 64,000 | 61,000 | 6,000 |

No extreme outliers were found (>20% above departmental average).

---

## 📊 Visualisation

`salary_outliers_visualisation.py` generates a bar chart of employees earning more than 20% above their department average, saved as `salary_outliers.png`.

```bash
python salary_outliers_visualisation.py
```

---

## 🚀 How to Run It

```bash
git clone https://github.com/moyanebarney-rgb/my_first_project_py.git
cd my_first_project_py
python my_first_project.py
```

The script generates 14 CSV files in the `outputs/` folder.

---

## 📂 Repository Structure

```
my_first_project_py/
├── my_first_project.py
├── salary_outliers_visualisation.py
├── requirements.txt
├── README.md
├── .gitignore
├── outputs/
│   ├── engineering_team.csv
│   ├── ... (all 14 CSVs)
│   └── salary_outliers.png
└── salary_by_department.png
```

---

## 🧠 Why This Matters

These are the same skills used in fiscal data analysis:

- Filtering to isolate specific departments or spending categories
- Joining to combine datasets (e.g., linking SOE financials to budget allocations)
- Aggregating to calculate totals (e.g., total maintenance spend per SOE)
- Sorting to identify highest-cost areas
- Filtering aggregates to find departments or categories that exceed thresholds
- Ranking to compare performance or spending across categories
- Subqueries to compare individual performance against averages
- CTEs to structure complex fiscal reports
- Window functions to rank or compare items within groups

This project is a foundation for more advanced data work in public finance and infrastructure economics.

---

## 📧 Author

**Samkele Barney Moyane**
Aspiring Fiscal Technocrat | Infrastructure Economics | Data Analysis

---

## 📝 License

This project is for educational and portfolio purposes.
