"""
my_first_project.py — SQL Portfolio

Builds a small employee/department SQLite database, then runs 14
progressive SQL queries (filtering -> joins -> aggregation -> window
functions -> outlier detection) and exports each result to a CSV file
in the outputs/ folder.

Run with:
    python my_first_project.py
"""

import os
import sqlite3
import pandas as pd

DB_PATH = "my_data.db"
OUTPUT_DIR = "outputs"


def build_database(conn):
    """Create tables and seed them with sample employee/department data."""
    cur = conn.cursor()

    cur.executescript(
        """
        DROP TABLE IF EXISTS employees;
        DROP TABLE IF EXISTS departments;

        CREATE TABLE departments (
            dept_id INTEGER PRIMARY KEY,
            dept_name TEXT NOT NULL,
            budget INTEGER NOT NULL
        );

        CREATE TABLE employees (
            emp_id INTEGER PRIMARY KEY,
            name TEXT NOT NULL,
            dept_id INTEGER NOT NULL,
            salary INTEGER NOT NULL,
            FOREIGN KEY (dept_id) REFERENCES departments(dept_id)
        );
        """
    )

    departments = [
        (1, "Engineering", 950000),
        (2, "Finance", 700000),
        (3, "Marketing", 500000),
        (4, "Operations", 400000),
    ]
    cur.executemany(
        "INSERT INTO departments (dept_id, dept_name, budget) VALUES (?, ?, ?)",
        departments,
    )

    employees = [
        # Engineering (71,000 - 92,000)
        (1, "Thabo Nkosi", 1, 71000),
        (2, "Lindiwe Dlamini", 1, 75500),
        (3, "Sipho Khumalo", 1, 78000),
        (4, "Naledi Mokoena", 1, 82000),
        (5, "Karabo Sithole", 1, 85000),
        (6, "Bongani Zulu", 1, 88500),
        (7, "Ayanda Mahlangu", 1, 92000),
        # Finance (72,000 - 95,000)
        (8, "Precious Radebe", 2, 72000),
        (9, "Zanele Mthembu", 2, 78000),
        (10, "Mandla Ngcobo", 2, 84000),
        (11, "Nomvula Cele", 2, 89000),
        (12, "Themba Buthelezi", 2, 95000),
        # Marketing (62,000 - 75,000)
        (13, "Palesa Moletsane", 3, 62000),
        (14, "Kagiso Modise", 3, 66500),
        (15, "Refilwe Tshabalala", 3, 71500),
        (16, "Sibusiso Mkhize", 3, 75000),
        # Operations (58,000 - 64,000)
        (17, "Nomsa Dube", 4, 58000),
        (18, "Vusi Maseko", 4, 60500),
        (19, "Thandeka Gumede", 4, 64000),
    ]
    cur.executemany(
        "INSERT INTO employees (emp_id, name, dept_id, salary) VALUES (?, ?, ?, ?)",
        employees,
    )

    conn.commit()


def run_query(conn, sql, filename, params=None):
    """Run a SQL query, export the result to CSV, and return the DataFrame."""
    df = pd.read_sql_query(sql, conn, params=params)
    path = os.path.join(OUTPUT_DIR, filename)
    df.to_csv(path, index=False)
    print(f"  -> {filename} ({len(df)} rows)")
    return df


def main():
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    conn = sqlite3.connect(DB_PATH)
    build_database(conn)

    print("Running 14 progressive SQL queries...\n")

    # 1. WHERE — filter employees by department
    run_query(
        conn,
        "SELECT * FROM employees WHERE dept_id = 1;",
        "engineering_team.csv",
    )

    # 2. JOIN — combine employee and department data
    run_query(
        conn,
        """
        SELECT e.emp_id, e.name, d.dept_name, e.salary, d.budget
        FROM employees e
        JOIN departments d ON e.dept_id = d.dept_id;
        """,
        "employees_with_budgets.csv",
    )

    # 3. WHERE > — employees earning above a threshold
    run_query(
        conn,
        "SELECT * FROM employees WHERE salary > 70000;",
        "high_earners.csv",
    )

    # 4. GROUP BY + SUM — total salary per department
    run_query(
        conn,
        """
        SELECT d.dept_name, SUM(e.salary) AS total_salary
        FROM employees e
        JOIN departments d ON e.dept_id = d.dept_id
        GROUP BY d.dept_name;
        """,
        "department_salary_totals.csv",
    )

    # 5. AVG, COUNT, ORDER BY — department statistics
    run_query(
        conn,
        """
        SELECT d.dept_name,
               COUNT(e.emp_id) AS employee_count,
               ROUND(AVG(e.salary), 2) AS avg_salary,
               SUM(e.salary) AS total_salary
        FROM employees e
        JOIN departments d ON e.dept_id = d.dept_id
        GROUP BY d.dept_name
        ORDER BY avg_salary DESC;
        """,
        "department_stats.csv",
    )

    # 6. HAVING — departments with avg salary > 70,000
    run_query(
        conn,
        """
        SELECT d.dept_name, ROUND(AVG(e.salary), 2) AS avg_salary
        FROM employees e
        JOIN departments d ON e.dept_id = d.dept_id
        GROUP BY d.dept_name
        HAVING AVG(e.salary) > 70000;
        """,
        "high_avg_departments.csv",
    )

    # 7. ORDER BY DESC — departments ranked by total salary
    run_query(
        conn,
        """
        SELECT d.dept_name, SUM(e.salary) AS total_salary
        FROM employees e
        JOIN departments d ON e.dept_id = d.dept_id
        GROUP BY d.dept_name
        ORDER BY total_salary DESC;
        """,
        "ranked_departments.csv",
    )

    # 8. Subquery — employees above their department's average salary
    run_query(
        conn,
        """
        SELECT e.name, d.dept_name, e.salary
        FROM employees e
        JOIN departments d ON e.dept_id = d.dept_id
        WHERE e.salary > (
            SELECT AVG(salary) FROM employees WHERE dept_id = e.dept_id
        );
        """,
        "above_dept_avg.csv",
    )

    # 9. CTE — department averages vs overall average
    run_query(
        conn,
        """
        WITH dept_avg AS (
            SELECT d.dept_name, AVG(e.salary) AS dept_avg_salary
            FROM employees e
            JOIN departments d ON e.dept_id = d.dept_id
            GROUP BY d.dept_name
        )
        SELECT dept_name,
               ROUND(dept_avg_salary, 2) AS dept_avg_salary,
               ROUND((SELECT AVG(salary) FROM employees), 2) AS overall_avg_salary
        FROM dept_avg;
        """,
        "dept_vs_overall_avg.csv",
    )

    # 10. ROW_NUMBER() — rank employees within department
    run_query(
        conn,
        """
        SELECT e.name, d.dept_name, e.salary,
               ROW_NUMBER() OVER (PARTITION BY d.dept_name ORDER BY e.salary DESC) AS dept_rank
        FROM employees e
        JOIN departments d ON e.dept_id = d.dept_id;
        """,
        "ranked_employees.csv",
    )

    # 11. LEAD() / LAG() — compare to previous/next salary
    run_query(
        conn,
        """
        SELECT e.name, d.dept_name, e.salary,
               LAG(e.salary) OVER (PARTITION BY d.dept_name ORDER BY e.salary) AS prev_salary,
               LEAD(e.salary) OVER (PARTITION BY d.dept_name ORDER BY e.salary) AS next_salary
        FROM employees e
        JOIN departments d ON e.dept_id = d.dept_id;
        """,
        "salary_comparison.csv",
    )

    # 12. RANK() / DENSE_RANK() — compare ranking methods
    run_query(
        conn,
        """
        SELECT e.name, d.dept_name, e.salary,
               RANK() OVER (PARTITION BY d.dept_name ORDER BY e.salary DESC) AS salary_rank,
               DENSE_RANK() OVER (PARTITION BY d.dept_name ORDER BY e.salary DESC) AS salary_dense_rank
        FROM employees e
        JOIN departments d ON e.dept_id = d.dept_id;
        """,
        "rank_comparison.csv",
    )

    # 13. CASE WHEN — high/low earner percentages
    run_query(
        conn,
        """
        SELECT d.dept_name,
               ROUND(100.0 * SUM(CASE WHEN e.salary > 75000 THEN 1 ELSE 0 END) / COUNT(*), 1) AS pct_high_earners,
               ROUND(100.0 * SUM(CASE WHEN e.salary <= 75000 THEN 1 ELSE 0 END) / COUNT(*), 1) AS pct_low_earners
        FROM employees e
        JOIN departments d ON e.dept_id = d.dept_id
        GROUP BY d.dept_name;
        """,
        "conditional_aggregation.csv",
    )

    # 14. Outlier detection — employees above 120% of department average
    run_query(
        conn,
        """
        SELECT e.name, d.dept_name, e.salary,
               ROUND(dept_avg.avg_salary, 2) AS dept_avg_salary,
               ROUND(100.0 * e.salary / dept_avg.avg_salary, 1) AS pct_of_avg
        FROM employees e
        JOIN departments d ON e.dept_id = d.dept_id
        JOIN (
            SELECT dept_id, AVG(salary) AS avg_salary
            FROM employees
            GROUP BY dept_id
        ) dept_avg ON e.dept_id = dept_avg.dept_id
        WHERE e.salary > 1.2 * dept_avg.avg_salary;
        """,
        "salary_outliers.csv",
    )

    conn.close()
    print("\nDone. All 14 CSV files written to outputs/.")


if __name__ == "__main__":
    main()
